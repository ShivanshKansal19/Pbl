from flask import Flask, render_template, request, url_for, redirect, session,jsonify
from bson import  json_util
import bcrypt
from pymongo import MongoClient
import json
app = Flask(__name__)
app.secret_key = "testing"

from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
uri = "mongodb+srv://admin:admin00@cluster0.ehauq5l.mongodb.net/hackathon?retryWrites=true&w=majority"
# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

app = Flask(__name__)
db = client['mydatabase']

@app.route('/submit-form', methods=['POST'])
def submit_form():
    username = request.form['username']
    vehicle = request.form['vehicle']
    email= request.form['email']
    phone=request.form['phone']
    password=request.form['password']
    gender=request.form['gender']
    # Insert form data into MongoDB
    collection = db['mycollection']
    data = {'username': username, 'vehicle': vehicle, 'email': email,'phone': phone,'password': password,'gender': gender}
    exist = collection.find_one({"email": email})
    print(exist)
    if(exist):
        return "User Already Exist"
    else:
        collection.insert_one(data)
        return 'Form submitted successfully!'
    
@app.route('/login-form',methods=['POST'])
def login_form():

    email= request.form['email']
    password=request.form['password']
    collection=db['mycollection']
    data = {'email': email, 'password': password}
    exist = collection.find_one({"email": email})
    print("exist",exist['password'])
    return "Login Sucessful"
@app.route('/Slot-form',methods=['POST'])
def slot_book():
    slot1=request.form['slots']
    collection=db['slotbooking']
    data={'slot': slot1}
   
    exist=collection.find_one({"slot":slot1})
    if(exist):
        return"Booked Already"
    else:
        collection.insert_one(data)
        return"Booked Successfully"
    
# @app.route("/all",methods=["GET"])
# def all():
#     collection=db['slotbooking']
#     cursor = collection.find()
#     json_data = [json_util.dumps(document) for document in cursor]
#     return jsonify(json_data)




if __name__=="__main__":
    app.run(debug=True,port=5000)