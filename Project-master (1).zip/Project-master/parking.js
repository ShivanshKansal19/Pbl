var div=document.getElementById('pay');
var display=1;
function changecolour(){
    if(display==1){
        div.style.display='grid';
        display = 1;
    }
    else{
        div.style.display='none';
        display=1;
    }
}